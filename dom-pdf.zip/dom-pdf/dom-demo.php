<?php
// include autoloader
require 'vendor/autoload.php';

// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class
$dompdf = new Dompdf();

$dompdf->set_option( 'isRemoteEnabled', true );

$html_data = '<html><body>
    <div class="table-wrapper">
        <table cellpadding="0" cellspacing="0">
            <tr>
                <td>
                    <table>
                        <tr>
                            <td><img src="/wp-content/uploads/2020/01/aws_logo.png" alt="Logo" style="width: 200px;"></td>
                        </tr>
                    </table>
                </td>
                <td>
                    <table style="width: 100px;">
                        <tr>
                            <td></td>
                        </tr>
                    </table>
                </td>
                <td>
                    <table>
                        <tr>
                            <td>
                                <h3 style="font-weight: 500; margin-bottom: 10px; ">Africa Web Solution</h3>
                                <p style="margin-top: 0; margin-bottom: 7px;">Address here Lorem ipsum dolor sit amet.
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore, obcaecati?</p>

                                <p style=" margin-bottom: 7px; margin-top: 7px;"><span
                                        style="font-weight: 600;">Contact:</span>&nbsp;&nbsp; 1234567890</p>
                                <p style=" margin-bottom: 7px; margin-top: 7px;"><span
                                        style="font-weight: 600;  margin-bottom: 8px;">E-mail:</span>&nbsp;&nbsp;text@example.com
                                </p>
                                <p style=" margin-bottom: 7px; margin-top: 7px;"><span
                                        style="font-weight: 600;  margin-bottom: 8px;">Order
                                        Date:</span>&nbsp;&nbsp;dd/mm/yyyy</p>
                                <p style=" margin-bottom: 7px; margin-top: 7px;"><span
                                        style="font-weight: 600;  margin-bottom: 8px;">Payment
                                        Status:</span>&nbsp;&nbsp;Completed</p>
                            </td>
                        </tr>
                    </table>
                </td>

            </tr>
        </table>

        <table style="width: 100%;" cellpadding="0" cellspacing="0">
            <tr>
                <td style="width: 100%; padding-left: 0; padding-right: 0;">
                    <table style="width: 100%;" cellpadding="0" cellspacing="0">
                        <tr>
                            <td
                                style="color: #fff; background: #d8b372; text-align: center; width: 100%; -webkit-print-color-adjust: exact; print-color-adjust: exact;">
                                <h3 style="margin-top: 5px; margin-bottom: 5px;">Tax Invoice</h3>
                            </td>
                        </tr>
                    </table>
                    <table style="width: 100%; border-collapse: collapse;" cellpadding="0" cellspacing="0">
                        <tr style=" border-bottom: 1pt solid #d4d4d4">
                            <td width="50%">
                                <table width="100%">
                                    <tr>
                                        <td width="25%">
                                            <p><span style="font-weight: 600;"> Name:</span> </p>
                                        </td>
                                        <td width="75%">
                                            <p>John Doe</p>
                                        </td>
                                    </tr>
                                </table>
                            <td width="50%">
                                <table width="100%">
                                    <tr>
                                        <td width="40%">
                                            <p><span style="font-weight: 600;">PNR No:</span> </p>
                                        </td>
                                        <td width="60%">
                                            <p>97846523</p>
                                        </td>
                                    </tr>
                                </table>
                            </td>

                        </tr>
                        <tr style=" border-bottom: 1pt solid #d4d4d4">
                            <td width="50%">
                                <table width="100%">
                                    <tr>
                                        <td width="25%">
                                            <p><span style="font-weight: 600;">E-mail:</span> </p>
                                        </td>
                                        <td width="75%">
                                            <p>John@Doe.com</p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td width="50%">
                                <table width="100%">
                                    <tr>
                                        <td width="40%">
                                            <p><span style="font-weight: 600;">Pickup Point:</span> </p>
                                        </td>
                                        <td width="60%">
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet similique
                                                maiores iste porro accusantium possimus saepe tempore, quibusdam eos
                                                quia?</p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr style=" border-bottom: 1pt solid #d4d4d4">
                            <td width="50%">
                                <table width="100%">
                                    <tr>
                                        <td width="25%">
                                            <p><span style="font-weight: 600;">Mobile:</span> </p>
                                        </td>
                                        <td width="75%">
                                            <p>9784653215</p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td width="50%">
                                <table width="100%">
                                    <tr>
                                        <td width="40%">
                                            <p><span style="font-weight: 600;">Drop Point:</span> </p>
                                        </td>
                                        <td width="60%">
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore
                                                architecto modi impedit quo quibusdam ad doloremque minus tempora,
                                                accusamus magni.</p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>

        <h3 style="font-weight:500;">Booking Details </h3>

        <table style="width: 100%; border:1px solid #d4d4d4; border-collapse: collapse;  " cellpadding="0"
            cellspacing="0">
            <thead>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Journey Date</th>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Name</th>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Age</th>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Gender</th>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Seat Type</th>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Amt</th>
                <th style="border:1px solid #d4d4d4; padding: 5px;">Total</th>
            </thead>
            <tbody>
                <tr>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>02-03-2022</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; min-width: 150px;">
                        <p>Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; max-width: 30px; ">
                        <p>25</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Female</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Standard Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
                <tr>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>02-03-2022</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; min-width: 150px;">
                        <p>Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; max-width: 30px; ">
                        <p>25</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Female</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Buisness Class</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
                <tr>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>02-03-2022</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; min-width: 150px;">
                        <p>Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; max-width: 30px; ">
                        <p>25</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Female</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Standard Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
                <tr>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>02-03-2022</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; min-width: 150px;">
                        <p>Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; max-width: 30px; ">
                        <p>25</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Female</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center;">
                        <p>Standard Lorem, ipsum dolor.</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
                

                <tr>
                    <td style="padding-left: 3px; padding-right:15px; border:1px solid #d4d4d4; text-align: right;"
                        colspan="6">
                        <p style="font-weight: 600;">Sub Total:</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
                <tr>
                    <td style="padding-left: 3px; padding-right:15px; border:1px solid #d4d4d4; text-align: right;"
                        colspan="6">
                        <p style="font-weight: 600;">GST@4%:</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
                <tr>

                    <td style="padding-left: 3px; padding-right:15px; border-right-style: hidden; text-align: left;"
                        colspan="4">
                        <p >Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, reprehenderit?</p>
                    </td>
                    <td style="padding-left: 3px; padding-right:15px; border:1px solid #d4d4d4; text-align: right;"
                        colspan="2">
                        <p style="font-weight: 600;"> Grand Total:</p>
                    </td>
                    <td
                        style="padding-left: 3px; padding-right:3px; border:1px solid #d4d4d4; text-align: center; text-wrap: nowrap;">
                        <p>200</p>
                    </td>
                </tr>
            </tbody>
        </table>

    </div>
</body>

</html>';

$dompdf->loadHtml( $html_data );

// (Optional) Setup the paper size and orientation
$dompdf->setPaper( 'A4', 'portraite' );

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
$dompdf->stream();
