<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-login.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woo.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

wp_enqueue_style( 'jquery-ui-css' );
wp_enqueue_script( 'jquery-ui-js' );

do_action( 'woocommerce_before_customer_login_form' ); ?>

<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

<div class="u-columns col2-set" id="customer_login">

	<div class="u-column1 col-1">

<?php endif; ?>
<div class="login-registration-form">
		<h2><?php esc_html_e( 'Login', 'winger' ); ?></h2>

		<form class="woocommerce-form woocommerce-form-login login" method="post">

			<?php do_action( 'woocommerce_login_form_start' ); ?>

			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username"><?php esc_html_e( 'Phone no. or email address', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
				<small><?php esc_html_e( 'Please enter phone no. without country code.', 'winger' ); ?></small>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="password"><?php esc_html_e( 'Password', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" />
			</p>

			<?php do_action( 'woocommerce_login_form' ); ?>

			<p class="form-row">
				<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
					<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Remember me', 'winger' ); ?></span>
				</label>
				<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
				<button type="submit" class="woocommerce-button button woocommerce-form-login__submit<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="login" value="<?php esc_attr_e( 'Log in', 'winger' ); ?>"><?php esc_html_e( 'Log in', 'winger' ); ?></button>
			</p>
			<p class="woocommerce-LostPassword lost_password">
				<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'winger' ); ?></a>
			</p>

			<?php do_action( 'woocommerce_login_form_end' ); ?>

		</form>
	</div>
	
</div>
<?php if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?>

	<div class="u-column2 col-2">

		<h2><?php esc_html_e( 'Register', 'winger' ); ?></h2>

		<form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >

			<?php do_action( 'woocommerce_register_form_start' ); ?>

			<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_username"><?php esc_html_e( 'Username', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
					<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
				</p>

			<?php endif; ?>

			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="first_name"><?php esc_html_e( 'First Name', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="text" placeholder="<?php esc_html_e( 'Enter your first name', 'winger' ); ?>" class="woocommerce-Input woocommerce-Input--text input-text" name="first_name" id="first_name" autocomplete="first_name" value="<?php echo ( ! empty( $_POST['first_name'] ) ) ? esc_attr( wp_unslash( $_POST['first_name'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="last_name"><?php esc_html_e( 'Last Name', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="text" placeholder="<?php esc_html_e( 'Enter your last name', 'winger' ); ?>" class="woocommerce-Input woocommerce-Input--text input-text" name="last_name" id="last_name" autocomplete="last_name" value="<?php echo ( ! empty( $_POST['last_name'] ) ) ? esc_attr( wp_unslash( $_POST['last_name'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide mtrap-date-field">
				<label for="mtrap_user_birth_date"><?php esc_html_e( 'Date of birth', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<input readonly type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="mtrap_user_birth_date" id="mtrap_user_birth_date" placeholder="<?php esc_html_e( 'dd-mm-yyyy', 'winger' ); ?>" autocomplete="mtrap_user_birth_date" value="<?php echo ( ! empty( $_POST['mtrap_user_birth_date'] ) ) ? esc_attr( wp_unslash( $_POST['mtrap_user_birth_date'] ) ) : ''; ?>">
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="mtrap_user_phone_number"><?php esc_html_e( 'Phone Number', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<div class="mtrap_country_phone">
					<input type="text" placeholder="<?php esc_html_e( 'Country code', 'winger' ); ?>" id="mtrap_user_phone_country_code" name="mtrap_user_phone_country_code" maxlength="6" size="11" value="<?php echo ( ! empty( $_POST['mtrap_user_phone_country_code'] ) ) ? esc_attr( wp_unslash( $_POST['mtrap_user_phone_country_code'] ) ) : ''; ?>" />
					
					<input type="text" placeholder="<?php esc_html_e( 'Enter your number', 'winger' ); ?>" class="woocommerce-Input woocommerce-Input--text input-text" name="mtrap_user_phone_number" id="mtrap_user_phone_number" autocomplete="phone" value="<?php echo ( ! empty( $_POST['mtrap_user_phone_number'] ) ) ? esc_attr( wp_unslash( $_POST['mtrap_user_phone_number'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
				</div>
			</p>
			
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="mtrap_user_gender"><?php esc_html_e( 'Gender', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<select name="mtrap_user_gender" id="mtrap_user_gender">
					<option value="Male"><?php esc_html_e( 'Male', 'winger' ); ?></option>
					<option value="Female"><?php esc_html_e( 'Female', 'winger' ); ?></option>
					<option value="Other"><?php esc_html_e( 'Other', 'winger' ); ?></option>
				</select>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="mrtap_passenger_type"><?php esc_html_e( 'Passenger Type', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<select name="mrtap_passenger_type" id="mrtap_passenger_type">
					<?php
					$mrtap_passenger_types = get_terms( array(
						'taxonomy' => 'passenger-type',
						'hide_empty' => false,
					) );

					if ( ! empty( $mrtap_passenger_types ) && ! is_wp_error( $mrtap_passenger_types ) ) {
						foreach ( $mrtap_passenger_types as $passenger_type ) {
							?>
							<option value="<?php echo esc_attr( $passenger_type->slug ); ?>"><?php echo esc_html( $passenger_type->name ); ?></option>
							<?php
						}
					}
					?>
				</select>
			</p>

			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="reg_email"><?php esc_html_e( 'Email address', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="email" placeholder="<?php esc_html_e( 'Enter your email', 'winger' ); ?>" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</p>
			
			<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_password"><?php esc_html_e( 'Password', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
					<input type="password" value="<?php echo ( ! empty( $_POST['password'] ) ) ? $_POST['password'] : ''; ?>" placeholder="<?php esc_html_e( 'Enter your password', 'winger' ); ?>"  class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
				</p>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_confirm_password"><?php esc_html_e( 'Confirm password', 'winger' ); ?>&nbsp;<span class="required">*</span></label>
					<input type="password" placeholder="<?php esc_html_e( 'Enter confirm password', 'winger' ); ?>"  value="<?php echo ( ! empty( $_POST['password'] ) ) ? $_POST['password'] : ''; ?>" class="woocommerce-Input woocommerce-Input--text input-text" name="reg_confirm_password" id="reg_confirm_password" autocomplete="new-password" />
				</p>

			<?php else : ?>

				<p><?php esc_html_e( 'A link to set a new password will be sent to your email address.', 'winger' ); ?></p>

			<?php endif; ?>

			<?php do_action( 'woocommerce_register_form' ); ?>

			<p class="woocommerce-form-row form-row">
				<?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
				<button type="submit" class="woocommerce-Button woocommerce-button button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?> woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'winger' ); ?>"><?php esc_html_e( 'Register', 'winger' ); ?></button>
			</p>

			<?php do_action( 'woocommerce_register_form_end' ); ?>

		</form>
		</div>
	</div>
<?php endif; ?>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>